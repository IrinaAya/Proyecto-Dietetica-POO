package ar.org.centro8.poo.curso.Tests;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.poo.curso.entities.Cliente;
import ar.org.centro8.poo.curso.entities.DetalleVenta;
import ar.org.centro8.poo.curso.entities.Producto;
import ar.org.centro8.poo.curso.entities.Proveedor;
import ar.org.centro8.poo.curso.entities.Venta;
import ar.org.centro8.poo.curso.repositories.ClienteRepository;
import ar.org.centro8.poo.curso.repositories.DetalleVentaRepository;
import ar.org.centro8.poo.curso.repositories.ProductoRepository;
import ar.org.centro8.poo.curso.repositories.ProveedorRepository;
import ar.org.centro8.poo.curso.repositories.VentaRepository;

import ar.org.centro8.poo.curso.repositories.interfaces.I_VentaRepository;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ProductoRepository;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ProveedorRespository;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ClienteRepository;
import ar.org.centro8.poo.curso.repositories.interfaces.I_DetalleVentaRepository;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.poo.curso")
public class TestRepositories {
    public static void main(String[] args) {
            try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_VentaRepository VentaRepository = context.getBean(VentaRepository.class);
            I_ProveedorRespository ProveedorRepository = context.getBean(ProveedorRepository.class);
            I_ProductoRepository ProductoRepository = context.getBean(ProductoRepository.class);
            I_DetalleVentaRepository DetalleVentaRepository = context.getBean(DetalleVentaRepository.class);
            I_ClienteRepository ClienteRepository = context.getBean(ClienteRepository.class);

            //Pruebas Ventas
            System.out.println("\n>>> Test 1: creando una nueva venta...");
            Venta nuevaVenta = new Venta(15, LocalDate.now(), 95632, 3); 
            VentaRepository.create(nuevaVenta);
            if (nuevaVenta.getIdVenta()>0) {
                System.out.println(" ## Venta creada exitosamente con el ID: " + nuevaVenta.getIdVenta());
                System.out.println(nuevaVenta);
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo crear la venta.");
            }

            System.out.println("\n>>> Test 2: Buscando venta por ID " + nuevaVenta.getIdVenta() + "...");
            Venta ventaEncontrada = VentaRepository.findById(nuevaVenta.getIdVenta());
            if (ventaEncontrada != null) {
                    System.out.println(" ## Venta encontrada: " + ventaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró la venta con el ID " + nuevaVenta.getIdVenta());
            }

            System.out.println("\n>>> Test 3: Listar todas las ventas...");
            List<Venta> todasLasVentas = VentaRepository.findAll();
            if (!todasLasVentas.isEmpty()) {
                System.out.println(" ## Ventas encontradas: " + todasLasVentas.size());
                todasLasVentas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron ventas !!");
            }
           
            System.out.println("\n>>> Test 4: Actualizando Venta " + nuevaVenta.getIdVenta() + " ...");
            nuevaVenta.setTotal(45812); 
            int filasAfectadasVenta = VentaRepository.update(nuevaVenta);
            if (filasAfectadasVenta==1) {
                System.out.println(" ## Venta " + nuevaVenta.getIdVenta() + " actualizada correctamente.");
                System.out.println(" ## Verificando actualización: " + VentaRepository.findById(nuevaVenta.getIdVenta()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar la venta !!");
            }

            System.out.println("\n>>> Test 5: eliminar venta " + nuevaVenta.getIdVenta()+"...");
            int filasAfectadasDelete = VentaRepository.delete(nuevaVenta.getIdVenta());
            if (filasAfectadasDelete == 1) {
                System.out.println(" ## Venta " + nuevaVenta.getIdVenta() + " eliminada correctamente");
                System.out.println("Verificando eliminación: " + VentaRepository.findById(nuevaVenta.getIdVenta()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar la venta !!");
            }
 
            System.out.println("\n>>> Test 6: Buscando ventas del cliente con ID 3...");
            List<Venta> ventasDelCliente = VentaRepository.findByCliente(3); 
            if (!ventasDelCliente.isEmpty()) {
            System.out.println(" ## Ventas encontradas para el cliente con ID 3: " + ventasDelCliente.size());
            ventasDelCliente.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron ventas para el cliente con ID 3 !!");
            }

            //Pruebas Proveedor
             System.out.println("\n>>> Test 7: Creando un nuevo proveedor...");
            Proveedor nuevoProveedor = new Proveedor(0, "China", "963254627", "chinazo@gmail.com", "Larraya 2354", "Entrega puntual", "Jueves", "Lunes");
            ProveedorRepository.create(nuevoProveedor);
            if (nuevoProveedor.getIdProveedor()>0) {
                System.out.println(" ## Proveedor creado correctamente con el ID " + nuevoProveedor.getIdProveedor());
                System.out.println(nuevoProveedor);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el proveedor !!");
            }

            System.out.println("\n>>> Test 8: Buscando proveedor por ID " + nuevoProveedor.getIdProveedor());
            Proveedor proveedorEncontrado = ProveedorRepository.findById(nuevoProveedor.getIdProveedor());
            if (proveedorEncontrado!=null) {
                System.out.println(" ## Proveedor encontrado: " + proveedorEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el proveedor con ID " + nuevoProveedor.getIdProveedor());
            }

            System.out.println("\n>>> Test 9: Listando todos los proveedores...");
            List<Proveedor> proveedores = ProveedorRepository.findAll();
            if (!proveedores.isEmpty()) {
                System.out.println(" ## Proveedores encontrados: " + proveedores.size());
                proveedores.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron proveedores !!");
            }

            System.out.println("\n>>> Test 10: Actualizando proveedor " + nuevoProveedor.getIdProveedor() + "...");
            nuevoProveedor.setNombre("Eugenia");
            int filasAfectadas = ProveedorRepository.update(nuevoProveedor);
            if (filasAfectadas == 1) {
                System.out.println(" ## Proveedor " + nuevoProveedor.getIdProveedor() + " actualizado correctamente.");
                System.out.println("Verificando actualización: " + ProveedorRepository.findById(nuevoProveedor.getIdProveedor()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar el proveedor !!");
            }

            System.out.println("\n>>> Test 11: eliminando el proveedor " + nuevoProveedor.getIdProveedor());
            int filasAfectadasProveedorEliminadas = ProveedorRepository.delete(nuevoProveedor.getIdProveedor());
            if (filasAfectadasProveedorEliminadas == 1) {
                System.out.println(" ## Proveedor " + nuevoProveedor.getIdProveedor() + " eliminado correctamente.");
                System.out.println("Verificando eliminación: " + ProveedorRepository.findById(nuevoProveedor.getIdProveedor()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el proveedor !!");
            }

            System.out.println("\n>>> Test 12 : Buscar proveedor por email: ");
            List<Proveedor> proveedoresPorEmail = ProveedorRepository.findByEmail("sandragranix@hotmail.com");
            if (!proveedoresPorEmail.isEmpty()) {
                System.out.println(" ## Proveedores encontrados con email sandragranix@hotmail.com: " + proveedoresPorEmail.size());
                proveedoresPorEmail.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró ningún proveedor con el email: sandragranix@hotmail.com");
            }
            //Pruebas Productos
            System.out.println("\n>>> Test 13: crear un nuevo producto...");
            Producto nuevoProducto = new Producto(0, "Yogur de soja endulzado con stevia y frutas.", 3500, 15, 5, true, true, false);
            ProductoRepository.create(nuevoProducto);
            if (nuevoProducto.getIdProducto()>0) {
                System.out.println("## Producto creado con el ID: "+ nuevoProducto.getIdProducto());
                System.out.println(nuevoProducto);
            } else {
                System.err.println(" ¡¡ERROR - No se pudo crear el nuevo producto !!");
            }

            System.out.println("\n>>> Test 14: buscar producto por ID: ");
            Producto productoEncontrado = ProductoRepository.findById(nuevoProducto.getIdProducto());
            if (productoEncontrado!=null) {
                System.out.println("## Producto encontrado: "+productoEncontrado);
            } else {
               System.err.println("¡¡ ERROR- no se encontró el producto con el ID" +nuevoProducto.getIdProducto()) ;
            }

            System.out.println("\n>>> Test 15: Listar todos los productos");
            List<Producto> productosTodos = ProductoRepository.findAll();
            if (!productosTodos.isEmpty()) {
                System.out.println("## Productos encontrados: "+ productosTodos.size());
                productosTodos.forEach(System.out::println);
            } else {
                System.err.println("## ERROR- no se encontraron productos");
            }

            System.out.println("\n>>> Test 16: Actualizar un producto:" + nuevoProducto.getIdProducto() + "...");
            nuevoProducto.setStock(20); 
            int filasAfectadasProducto = ProductoRepository.update(nuevoProducto); 
            if (filasAfectadasProducto == 1) {
                System.out.println("## Producto " + nuevoProducto.getIdProducto() + " actualizado correctamente");
                System.out.println("## Verificando actualización: " + ProductoRepository.findById(nuevoProducto.getIdProducto()));
            } else {
                System.err.println("¡¡ ERROR - No se pudo actualizar el producto !!");
            }

            System.out.println("\n>>> Test 17: Eliminar un producto: "+ nuevoProducto.getIdProducto());
            int filasAfectadasDeleteProducto = ProductoRepository.delete(nuevoProducto.getIdProducto());
            if (filasAfectadasDeleteProducto==1) {
                System.out.println("## Producto "+nuevoProducto.getIdProducto()+" eliminado correctamente");
                System.out.println("Verificando eliminación "+ ProductoRepository.findById(nuevoProducto.getIdProducto()));
            } else {
                System.err.println(" ¡¡ERROR- No se pudo eliminar el producto");
            }

            System.out.println("\n>>> Test 18: encontrar producto por proveedor");
            List<Producto> productosPorProveedor = ProductoRepository.findByProveedor(3);
            if (!productosPorProveedor.isEmpty()) {
                System.out.println(" ## Productos encontrados para el proveedor con ID 3: " + productosPorProveedor.size());
                productosPorProveedor.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron productos para el proveedor con ID 3");
            }
            //Pruebas DetalleVenta
            
            System.out.println("\n>>> Test 19: crear un nuevo DetalleVenta");
            DetalleVenta nuevoDV = new DetalleVenta(1, 9, 10); 
            DetalleVentaRepository.create(nuevoDV);
            System.out.println(" ## Detalle creado para Venta ID: " + nuevoDV.getIdVenta() + " y Producto ID: " + nuevoDV.getIdProducto());

            System.out.println("\n>>> Test 20: busquemos DetalleVenta por id_venta y id_producto");
            DetalleVenta detalleVEncontrado = DetalleVentaRepository.findById(5, 1);
            if (detalleVEncontrado != null) {
                System.out.println(" ## Detalle encontrado: " + detalleVEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el detalle venta con id_venta 5 y id_producto 1");
            }

            System.out.println("\n>>> Test 21: Listar todos los Detalles Ventas: ");
            List<DetalleVenta> todosDV = DetalleVentaRepository.findAll();
            if (!todosDV.isEmpty()) {
                System.out.println(" ## Detalles de ventas totales: " + todosDV.size());
                todosDV.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detalle_venta");
            }

            System.out.println("\n>>> Test 22: Actualizar  cantidad Detalle_Venta:");
            nuevoDV.setCantidad(25);
            int filasAfectadasDV = DetalleVentaRepository.update(nuevoDV);
            if (filasAfectadasDV==1) {
                System.out.println(" ## Detalle actualizado correctamente.");
                System.out.println(" ## Verificando: " + DetalleVentaRepository.findById(nuevoDV.getIdVenta(), nuevoDV.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar el detalle");
            }

            System.out.println("\n>>> Test 23 : Eliminar un Detalle_Venta"+ nuevoDV.getIdVenta()+ nuevoDV.getIdProducto());
            int filasEliminadasDV = DetalleVentaRepository.delete(nuevoDV.getIdVenta(), nuevoDV.getIdProducto());
            if (filasEliminadasDV==1) {
                System.out.println(" ## Detalle eliminado correctamente.");
                System.out.println(" ## Verificando eliminación:" +DetalleVentaRepository.findById(nuevoDV.getIdVenta(), nuevoDV.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el detalle !!");
            }

            System.out.println("\n>>> Test 24: buscar detalle_venta ID 5: ");
            List<DetalleVenta> detallesPorVenta = DetalleVentaRepository.findByVenta(5);
            if (!detallesPorVenta.isEmpty()) {
                System.out.println(" ## Detalles encontrados: " + detallesPorVenta.size());
                detallesPorVenta.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron detalles de la venta 5");
            }

            //Pruebas Cliente
             
            System.out.println("\n>>> Test 25: Crear un nuevo cliente...");
            Cliente nuevoCliente = new Cliente(0, "Martina", "Dona", "406538462", "659530032", "martudo@gmail.com");
            ClienteRepository.create(nuevoCliente);
            if (nuevoCliente.getIdCliente()>0) {
                System.out.println("## Cliente creado con ID: " + nuevoCliente.getIdCliente());
                System.out.println(nuevoCliente);
            } else{
                System.err.println("¡¡ ERROR - No se pudo crear el cliente !!");
            }

            System.out.println("\n>>> Test 26: buscar un cliente por ID "+ nuevoCliente.getIdCliente());
            Cliente clienteEncontrado = ClienteRepository.findById(nuevoCliente.getIdCliente());
            if (clienteEncontrado!=null) {
                System.out.println("## Cliente encontrado "+ clienteEncontrado);
            } else {
                System.err.println("## ¡¡ ERROR- no se encontró el cliente por el ID "+nuevoCliente.getIdCliente());
            }

            System.out.println("\n>>> Test 27: Listar todos los clientes");
            List<Cliente> clientesTodos = ClienteRepository.findAll();
            if (!clientesTodos.isEmpty()) {
                System.out.println("## clientes encontrado: "+clientesTodos.size());
                clientesTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡ERROR - no se encontraron clientes ");
            }

            System.out.println("\n>>> Test 27:actualizamos un cliente"+nuevoCliente.getIdCliente());
            nuevoCliente.setNombreCliente("Kalani");
            nuevoCliente.setApellidoCliente("Romero");
            int filasAfectadaCliente = ClienteRepository.update(nuevoCliente);
            if (filasAfectadaCliente==1) {
                System.out.println("## Cliente "+nuevoCliente.getIdCliente()+ "actuaizado correctamente. ");
                System.out.println("Verificando actualización: "+ClienteRepository.findById(nuevoCliente.getIdCliente()));
            } else {
                System.err.println("## Error - no se pudo actualizar el cliente");
            }

            System.out.println("\n>>> Test 28: eliminamos un cliente "+nuevoCliente.getIdCliente());
            int filasAfectadasClienteDelete = ClienteRepository.delete(nuevoCliente.getIdCliente());
            if (filasAfectadasClienteDelete == 1) {
                System.out.println("## Cliente"+nuevoCliente.getIdCliente()+ "eliminado correctamente.");
                System.out.println("Verificando eliminación: "+ClienteRepository.findById(nuevoCliente.getIdCliente()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar al cliente");
            }

            System.out.println("\n>>> Test 29: Buscando cliente por email");
            List<Cliente> clientesEncontrados = ClienteRepository.findByEmail("stefan.romero@hotmail.com");
            if (!clientesEncontrados.isEmpty()) {
                System.out.println(" ## Cliente encontrado con email:");
                clientesEncontrados.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró cliente con ese email");
            }

        } catch (Exception e) {
            System.out.println(" ¡¡ ERROR de la Base de Datos durante las pruebas !!");
            e.printStackTrace();
        } finally{
            System.out.println("\n <<< FINALIZANDO PRUEBAS >>>");
            System.out.println("<<< CONTEXTO DE SPRING CERRADO >>>");
        }
    }
}