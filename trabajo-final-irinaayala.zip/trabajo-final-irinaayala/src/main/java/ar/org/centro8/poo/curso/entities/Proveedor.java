package ar.org.centro8.poo.curso.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Proveedor {
    private int idProveedor;
    private String nombre;
    private String telefono;
    private String email;
    private String direccion;
    private String observaciones;
    private String tomaPedidos;
    private String entregaPedidos;
}
