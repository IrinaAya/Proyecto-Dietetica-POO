package ar.org.centro8.poo.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.poo.curso.entities.Cliente;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ClienteRepository;

@Repository
public class ClienteRepository implements I_ClienteRepository{
    private final DataSource DATASOURCE;
    
    private static final String SQL_CREATE =
    "INSERT INTO clientes(nombre_cliente, apellido_cliente, dni, telefono, email) VALUES (?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID=
    "SELECT * FROM clientes WHERE id_cliente=?";

    private static final String SQL_FIND_ALL=
    "SELECT * FROM clientes";

    private static final String SQL_UPDATE =
    "UPDATE clientes SET nombre_cliente =?, apellido_cliente =?, dni =?, telefono =?, email =? WHERE id=?";

    private static final String SQL_DELETE =
    "DELETE FROM clientes WHERE id=?";

    private static final String SQL_FIND_BY_EMAIL =
    "SELECT * FROM clientes WHERE email=?";
    
    public ClienteRepository(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Cliente cliente) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombreCliente());
            ps.setString(2, cliente.getApellidoCliente());
            ps.setString(3, cliente.getDni());
            ps.setString(4, cliente.getTelefono());
            ps.setString(5, cliente.getEmail());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    cliente.setIdCliente(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Cliente findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Cliente> findAll() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while(rs.next()) {
                clientes.add(mapRow(rs));
            }
        }
        return clientes;
    }

    @Override
    public int update(Cliente cliente) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, cliente.getNombreCliente());
            ps.setString(2, cliente.getApellidoCliente());
            ps.setString(3, cliente.getDni());
            ps.setString(4, cliente.getTelefono());
            ps.setString(5, cliente.getEmail());
            ps.setInt(6, cliente.getIdCliente());
            int filasAfectadas = ps.executeUpdate(); 
            return filasAfectadas; 
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate(); 
            return filasAfectadas; 
        }
    }

    @Override
    public List<Cliente> findByEmail(String email) throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EMAIL)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    clientes.add(mapRow(rs));
                }
            }
        }
        return clientes;
    }

    private Cliente mapRow(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setIdCliente(rs.getInt("id_cliente"));
        c.setNombreCliente(rs.getString("nombre_cliente"));
        c.setApellidoCliente(rs.getString("apellido_cliente"));
        c.setDni(rs.getString("dni"));
        c.setTelefono(rs.getString("telefono"));
        c.setEmail(rs.getString("email"));
        return c;
    }

}
