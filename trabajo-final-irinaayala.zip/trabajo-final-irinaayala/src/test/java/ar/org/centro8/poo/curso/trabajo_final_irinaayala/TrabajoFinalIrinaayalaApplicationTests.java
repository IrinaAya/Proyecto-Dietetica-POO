package ar.org.centro8.poo.curso.trabajo_final_irinaayala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoFinalIrinaayalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
