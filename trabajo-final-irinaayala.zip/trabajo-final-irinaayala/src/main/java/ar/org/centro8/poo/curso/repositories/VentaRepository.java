package ar.org.centro8.poo.curso.repositories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.poo.curso.entities.Venta;
import ar.org.centro8.poo.curso.repositories.interfaces.I_VentaRepository;

@Repository
public class VentaRepository implements I_VentaRepository{

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
        "INSERT INTO ventas (fecha, total, id_cliente) VALUES (?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM ventas WHERE id_venta =?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM ventas";
    private static final String SQL_UPDATE =
        "UPDATE ventas SET fecha =?, total =?, id_cliente =? WHERE id_venta =?";
    private static final String SQL_DELETE =
        "DELETE FROM ventas WHERE id_venta =?";
    private static final String SQL_FIND_BY_CLIENTE =
        "SELECT * FROM ventas WHERE id_cliente =?";

    public VentaRepository(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

     @Override
    public void create(Venta venta) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setDate(1, Date.valueOf(venta.getFecha()));
            ps.setInt(2, venta.getTotal());
            ps.setInt(3, venta.getIdCliente());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    venta.setIdVenta(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Venta findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Venta> findAll() throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ventas.add(mapRow(rs));
            }
        }
        return ventas;
    }

    @Override
    public int update(Venta venta) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setDate(1, Date.valueOf(venta.getFecha()));
            ps.setInt(2, venta.getTotal());
            ps.setInt(3, venta.getIdCliente());
            ps.setInt(4, venta.getIdVenta());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Venta> findByCliente(int idCliente) throws SQLException {
        List<Venta> clientes = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_CLIENTE)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    clientes.add(mapRow(rs));
                }
            }
        }
        return clientes;
    }

    private Venta mapRow(ResultSet rs) throws SQLException {
        Venta v = new Venta();
        v.setIdVenta(rs.getInt("id_venta"));
        v.setFecha(rs.getDate("fecha").toLocalDate());
        v.setTotal(rs.getInt("total"));
        v.setIdCliente(rs.getInt("id_cliente"));
        return v;
    }
}


