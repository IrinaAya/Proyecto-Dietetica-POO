package ar.org.centro8.poo.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.poo.curso.entities.DetalleVenta;

public interface I_DetalleVentaRepository {
    void create(DetalleVenta dv) throws SQLException;
    DetalleVenta findById(int idVenta, int idProducto) throws SQLException;
    List<DetalleVenta> findAll() throws SQLException;
    int update(DetalleVenta DetalleVenta) throws SQLException;
    int delete(int idVenta, int idProducto) throws SQLException;
    List<DetalleVenta> findByVenta(int idVenta) throws SQLException;
    
 
}


