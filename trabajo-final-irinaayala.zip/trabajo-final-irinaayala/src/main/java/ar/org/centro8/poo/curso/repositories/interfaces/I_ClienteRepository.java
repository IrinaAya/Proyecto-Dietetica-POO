package ar.org.centro8.poo.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.poo.curso.entities.Cliente;

public interface I_ClienteRepository {
    void create(Cliente cliente) throws SQLException;
    Cliente findById(int id) throws SQLException;
    List<Cliente> findAll() throws SQLException;
    int update(Cliente cliente) throws SQLException;
    int delete(int id) throws SQLException;
    List<Cliente> findByEmail(String email) throws SQLException;
}
