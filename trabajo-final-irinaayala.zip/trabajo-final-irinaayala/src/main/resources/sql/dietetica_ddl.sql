-- drop database if exists dietetica;
-- CREATE DATABASE dietetica;
use dietetica;

CREATE TABLE clientes(
    id_cliente INT auto_increment primary key,
    nombre_cliente varchar(25) not null,
    apellido_cliente varchar(25) not null,
    dni varchar(20) UNIQUE not null,
    telefono varchar(20) not null,
    email varchar(50) not null
  
);

CREATE TABLE proveedores(
    id_proveedor INT auto_increment primary key,
    nombre varchar(25) not null,
    telefono varchar(20) not null,
    email varchar(50)not null,
    direccion varchar(200)not null,
    observaciones varchar(50) not null,
    toma_pedidos varchar(30),
    entrega_pedidos varchar(30)
);

CREATE TABLE productos(
    id_producto INT auto_increment primary key,
    nombre_producto varchar(50) not null,
    precio INT not null,
    stock INT not null,
    id_proveedor INT not null,
    apto_diabetico boolean,
    apto_vegano boolean,
    apto_celiaco boolean
);

ALTER TABLE productos ADD constraint fk_productos_proveedores
foreign key (id_proveedor) references proveedores(id_proveedor);

CREATE TABLE ventas(
    id_venta INT auto_increment primary key ,
    fecha DATE not null,
    total INT,
    id_cliente INT not null
);

ALTER TABLE ventas ADD CONSTRAINT fk_ventas_clientes
foreign key (id_cliente) references clientes(id_cliente);

CREATE TABLE detalle_ventas(
    id_venta INT not NULL,
    id_producto INT not NULL,
    cantidad INT NOT NULL CHECK (cantidad > 0),
    PRIMARY KEY (id_venta, id_producto)
);

ALTER TABLE detalle_ventas ADD CONSTRAINT fk_detalle_ventas_ventas
foreign key (id_venta) references ventas(id_venta);

ALTER TABLE detalle_ventas ADD CONSTRAINT fk_detalle_ventas_productos
foreign key (id_producto) references productos(id_producto);