package ar.org.centro8.poo.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.poo.curso.entities.Venta;

public interface I_VentaRepository {
    void create(Venta venta) throws SQLException;
    Venta findById(int id) throws SQLException;
    List<Venta> findAll() throws SQLException;
    int update(Venta venta) throws SQLException;
    int delete(int id) throws SQLException;
    List<Venta> findByCliente(int idCliente) throws SQLException;

}
