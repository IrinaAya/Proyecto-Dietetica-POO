package ar.org.centro8.poo.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.poo.curso.entities.DetalleVenta;
import ar.org.centro8.poo.curso.repositories.interfaces.I_DetalleVentaRepository;
@Repository
public class DetalleVentaRepository implements I_DetalleVentaRepository{
    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
        "INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES (?,?,?)";  
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM detalle_ventas WHERE id_venta =? AND id_producto =?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM detalle_ventas";
    private static final String SQL_UPDATE =
        "UPDATE detalle_ventas SET cantidad = ? WHERE id_venta =? AND id_producto =?";
    private static final String SQL_DELETE =
        "DELETE FROM detalle_ventas WHERE id_venta=? AND id_producto=?";
    private static final String SQL_FIND_BY_VENTA =
        "SELECT * FROM detalle_ventas WHERE id_venta =?";
    

    public DetalleVentaRepository(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(DetalleVenta detalleventa) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setInt(1, detalleventa.getIdVenta());
            ps.setInt(2, detalleventa.getIdProducto());
            ps.setInt(3, detalleventa.getCantidad());
            ps.executeUpdate();
        }
    }

    @Override
    public DetalleVenta findById(int idVenta, int idProducto) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<DetalleVenta> findAll() throws SQLException {
        List<DetalleVenta> detalleVentas = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                detalleVentas.add(mapRow(rs));
            }
        }
        return detalleVentas;
    }

    @Override
    public int update(DetalleVenta detalleVenta) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, detalleVenta.getCantidad());
            ps.setInt(2, detalleVenta.getIdVenta());
            ps.setInt(3, detalleVenta.getIdProducto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int idVenta, int idProducto) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<DetalleVenta> findByVenta(int idVenta) throws SQLException {
        List<DetalleVenta> detalleVentas = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_VENTA)) {
            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    detalleVentas.add(mapRow(rs));
                }
            }
        }
        return detalleVentas;
    }


    private DetalleVenta mapRow(ResultSet rs) throws SQLException {
        DetalleVenta dv = new DetalleVenta();
        dv.setIdVenta(rs.getInt("id_venta"));
        dv.setIdProducto(rs.getInt("id_producto"));
        dv.setCantidad(rs.getInt("cantidad"));
        return dv;
    }
}


