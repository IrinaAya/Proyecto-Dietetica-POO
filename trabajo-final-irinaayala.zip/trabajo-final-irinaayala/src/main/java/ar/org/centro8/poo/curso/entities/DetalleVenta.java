package ar.org.centro8.poo.curso.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetalleVenta {
    private int idVenta;
    private int idProducto;
    private int cantidad;
}

