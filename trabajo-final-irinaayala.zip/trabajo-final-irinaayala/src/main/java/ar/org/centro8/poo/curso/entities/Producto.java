package ar.org.centro8.poo.curso.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Producto {
    private int idProducto;
    private String nombreProducto;
    private int precio;
    private int stock;
    private int idProveedor;
    private boolean aptoDiabetico;
    private boolean aptoVegano;
    private boolean aptoCeliaco;
}

