package ar.org.centro8.poo.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.poo.curso.entities.Proveedor;

public interface I_ProveedorRespository {
    void create(Proveedor proveedor) throws SQLException;
    Proveedor findById(int id) throws SQLException;
    List<Proveedor> findAll() throws SQLException;
    int update(Proveedor proveedor) throws SQLException;
    int delete(int id) throws SQLException;
    List<Proveedor> findByEmail(String email) throws SQLException;

}
