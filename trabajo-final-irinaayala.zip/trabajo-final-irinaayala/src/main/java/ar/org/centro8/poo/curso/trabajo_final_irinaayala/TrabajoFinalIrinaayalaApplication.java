package ar.org.centro8.poo.curso.trabajo_final_irinaayala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoFinalIrinaayalaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoFinalIrinaayalaApplication.class, args);
	}

}
