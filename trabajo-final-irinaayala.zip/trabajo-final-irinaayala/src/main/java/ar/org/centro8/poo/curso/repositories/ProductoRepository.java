package ar.org.centro8.poo.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.poo.curso.entities.Producto;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ProductoRepository;
@Repository
public class ProductoRepository implements I_ProductoRepository{
    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
    "INSERT INTO productos (nombre_producto, precio, stock, id_proveedor, apto_diabetico, apto_vegano, apto_celiaco) VALUES (?,?,?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID =
    "SELECT * FROM productos WHERE id_producto =?";

    private static final String SQL_FIND_ALL =
    "SELECT * FROM productos";

    private static final String SQL_UPDATE =
    "UPDATE productos SET nombre_producto =?, precio =?, stock =?, id_proveedor =?, apto_diabetico =?, apto_vegano =?, apto_celiaco =? WHERE id_producto =?";

    private static final String SQL_DELETE =
    "DELETE FROM productos WHERE id_producto =?";

    private static final String SQL_FIND_BY_PROVEEDOR =
    "SELECT * FROM productos WHERE id_proveedor =?";

    public ProductoRepository(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Producto producto) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, producto.getNombreProducto());
            ps.setInt(2, producto.getPrecio());
            ps.setInt(3, producto.getStock());
            ps.setInt(4, producto.getIdProveedor());
            ps.setBoolean(5, producto.isAptoDiabetico());
            ps.setBoolean(6, producto.isAptoVegano());
            ps.setBoolean(7, producto.isAptoCeliaco());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    producto.setIdProducto(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Producto findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Producto> findAll() throws SQLException {
        List<Producto> productos = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                productos.add(mapRow(rs));
            }
        }
        return productos;
    }

    @Override
    public int update(Producto producto) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, producto.getNombreProducto());
            ps.setInt(2, producto.getPrecio());
            ps.setInt(3, producto.getStock());
            ps.setInt(4, producto.getIdProveedor());
            ps.setBoolean(5, producto.isAptoDiabetico());
            ps.setBoolean(6, producto.isAptoVegano());
            ps.setBoolean(7, producto.isAptoCeliaco());
            ps.setInt(8, producto.getIdProducto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Producto> findByProveedor(int idProveedor) throws SQLException {
        List<Producto> productos = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_PROVEEDOR)) {
            ps.setInt(1, idProveedor);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    productos.add(mapRow(rs));
                }
            }
        }
        return productos;
    }

    private Producto mapRow(ResultSet rs) throws SQLException {
        Producto p = new Producto();
        p.setIdProducto(rs.getInt("id_producto"));
        p.setNombreProducto(rs.getString("nombre_producto"));
        p.setPrecio(rs.getInt("precio"));
        p.setStock(rs.getInt("stock"));
        p.setIdProveedor(rs.getInt("id_proveedor"));
        p.setAptoDiabetico(rs.getBoolean("apto_diabetico"));
        p.setAptoVegano(rs.getBoolean("apto_vegano"));
        p.setAptoCeliaco(rs.getBoolean("apto_celiaco"));
        return p;
    }
}

