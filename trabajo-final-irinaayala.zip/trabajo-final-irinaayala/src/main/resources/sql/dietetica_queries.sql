-- Productos apto diabético
select nombre_producto, precio
from productos where apto_diabetico = TRUE;
-- Productos apto vegano
select nombre_producto, precio
from productos where apto_vegano = TRUE;
-- Productos apto celiaco
select nombre_producto, precio
from productos where apto_celiaco = TRUE;
-- En campo cliente trae lo nombres de los clientes que contengan una e
select * from clientes where nombre_cliente like '%e%';
-- Trae proveedores que el email contenga nola
select * from proveedores where email like '%nola%';
-- Une las tablas ventas y cliente para que traiga quien hizo cada compra
select v.id_venta, v.fecha, c.nombre_cliente, c.apellido_cliente, v.total
from ventas v 
join clientes c 
on v.id_cliente = c.id_cliente;
-- Ventas que tiene el cliente Katherine
select v.id_venta, v.fecha, c.nombre_cliente, v.total
from ventas v
join clientes c 
on v.id_cliente = c.id_cliente
where c.nombre_cliente = 'Katherine';
-- Productos que su precio es mayor a 2500
select v.id_venta, c.nombre_cliente, p.nombre_producto, p.precio, dv.cantidad
from ventas v
join clientes c on v.id_cliente = c.id_cliente
join detalle_ventas dv on v.id_venta = dv.id_venta
join productos p on dv.id_producto = p.id_producto
where p.precio > 2500;

