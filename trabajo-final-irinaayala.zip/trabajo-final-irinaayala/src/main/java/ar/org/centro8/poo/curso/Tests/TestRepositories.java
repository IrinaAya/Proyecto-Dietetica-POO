package ar.org.centro8.poo.curso.Tests;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.poo.curso.entities.Proveedor;
import ar.org.centro8.poo.curso.entities.Venta;

import ar.org.centro8.poo.curso.repositories.ProveedorRepository;
import ar.org.centro8.poo.curso.repositories.VentaRepository;

import ar.org.centro8.poo.curso.repositories.interfaces.I_VentaRepository;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ProveedorRespository;;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.poo.curso")
public class TestRepositories {
    public static void main(String[] args) {
            try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_VentaRepository VentaRepository = context.getBean(VentaRepository.class);
            I_ProveedorRespository ProveedorRepository = context.getBean(ProveedorRepository.class);
    //        I_ProductoRepository ProductoRepository = context.getBean(ProductoRepository.class);
       //     I_DetalleVentaRepository DetalleVentaRepository = context.getBean(DetalleVentaRepository.class);
           // I_ClienteRepository ClienteRepository = context.getBean(ClienteRepository.class);

              //////////////////////////////////////////////////////////////////////

            System.out.println("\n>>> Test 1: creando una nueva venta...");
            Venta nuevaVenta = new Venta(15, LocalDate.now(), 95632, 3); 
            VentaRepository.create(nuevaVenta);
            if (nuevaVenta.getIdVenta()>0) {
                System.out.println(" ## Venta creada exitosamente con el ID: " + nuevaVenta.getIdVenta());
                System.out.println(nuevaVenta);
            } else {
                System.err.println("ERROR! No se pudo crear la venta.");
            }
            ////////////////////////////////////////////////////////////////////////7
            System.out.println("\n>>> Test 2: Buscando venta por ID " + nuevaVenta.getIdVenta() + "...");
            Venta ventaEncontrada = VentaRepository.findById(nuevaVenta.getIdVenta());
            if (ventaEncontrada != null) {
                    System.out.println(" ## Venta encontrada: " + ventaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró la venta con el ID " + nuevaVenta.getIdVenta());
            }
        ////////////////////////////////////////////////////////////////////////////////
            System.out.println("\n>>> Test 3: Listando todas las ventas...");
            List<Venta> todasLasVentas = VentaRepository.findAll();
            if (!todasLasVentas.isEmpty()) {
                System.out.println(" ## Ventas encontradas: " + todasLasVentas.size());
                todasLasVentas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron ventas !!");
            }
           
            /////////////////////////////////////////////////////////////////////////////
            System.out.println("\n>>> Test 4: Actualizando Venta " + nuevaVenta.getIdVenta() + " ...");
            nuevaVenta.setTotal(45812); 
            int filasAfectadasVenta = VentaRepository.update(nuevaVenta);
            if (filasAfectadasVenta==1) {
                System.out.println(" ## Venta " + nuevaVenta.getIdVenta() + " actualizada correctamente.");
                System.out.println(" ## Verificando actualización: " + VentaRepository.findById(nuevaVenta.getIdVenta()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar la venta !!");
            }
            ////////////////////////////////////////////////////////////////////////////7
            System.out.println("\n>>> Test 5: eliminando la venta " + nuevaVenta.getIdVenta());
            int filasAfectadasDelete = VentaRepository.delete(nuevaVenta.getIdVenta());

            if (filasAfectadasDelete == 1) {
                System.out.println(" ## Venta " + nuevaVenta.getIdVenta() + " eliminada correctamente");
                System.out.println("Verificando eliminación: " + VentaRepository.findById(nuevaVenta.getIdVenta()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar la venta !!");
            }
            ////////////////////////////////////////
            System.out.println("\n>>> Test 6: Buscando ventas del cliente con ID 2...");
            List<Venta> ventasCliente =VentaRepository.findByCliente(2);
            if (!ventasCliente.isEmpty()) {
                for (Venta v : ventasCliente) {
                    System.out.println("Venta " + v.getIdVenta() + ": " + v);
                    System.out.println("==================================");
                }
            } else {
                System.err.println("No hay ventas del cliente.");
            }

            ////////////////////////////////////////////////////////////////////////////////////
             System.out.println("\n>>> Test 7: Creando un nuevo proveedor...");
            Proveedor nuevoProveedor = new Proveedor(0, "China", "963254627", "chinazo@gmail.com", "Larraya 2354", "Entrega puntual", "Jueves", "Lunes");
            ProveedorRepository.create(nuevoProveedor);
            if (nuevoProveedor.getIdProveedor()>0) {
                System.out.println(" ## Proveedor creado correctamente con ID " + nuevoProveedor.getIdProveedor());
                System.out.println(nuevoProveedor);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el proveedor !!");
            }
            /////////////////////////////////////////////////////////////////////////
            System.out.println("\n>>> Test 8: Buscando proveedor por ID " + nuevoProveedor.getIdProveedor() + "...");
            Proveedor proveedorEncontrado = ProveedorRepository.findById(nuevoProveedor.getIdProveedor());
            if (proveedorEncontrado!=null) {
                System.out.println(" ## Proveedor encontrado: " + proveedorEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el proveedor con ID " + nuevoProveedor.getIdProveedor());
            }
            ///////////////////////////////////////////////////////////////////////////////////////////
            System.out.println("\n>>> Test 9: Listando todos los proveedores...");
            List<Proveedor> proveedores = ProveedorRepository.findAll();
            if (!proveedores.isEmpty()) {
                System.out.println(" ## Proveedores encontrados: " + proveedores.size());
                proveedores.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron proveedores !!");
            }
            ////////////////////////////////////////////////////////////////////////////
            System.out.println("\n>>> Test 10: Actualizando proveedor " + nuevoProveedor.getIdProveedor() + "...");
            nuevoProveedor.setTelefono("963548216");
            nuevoProveedor.setObservaciones("Trae los sabados");
            int filasAfectadas = ProveedorRepository.update(nuevoProveedor);
            if (filasAfectadas == 1) {
                System.out.println(" ## Proveedor " + nuevoProveedor.getIdProveedor() + " actualizado correctamente.");
                System.out.println("Verificando actualización: " + ProveedorRepository.findById(nuevoProveedor.getIdProveedor()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar el proveedor !!");
            }
            /////////////////////////////////////////////////////////////////////////////////////////
            System.out.println("\n>>> Test 11: eliminando el proveedor " + nuevoProveedor.getIdProveedor());
            int filasAfectadasProveedorEliminadas = ProveedorRepository.delete(nuevoProveedor.getIdProveedor());
            if (filasAfectadasProveedorEliminadas == 1) {
                System.out.println(" ## Proveedor " + nuevoProveedor.getIdProveedor() + " eliminado correctamente.");
                System.out.println("Verificando eliminación: " + ProveedorRepository.findById(nuevoProveedor.getIdProveedor()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el proveedor !!");
            }
            
        } catch (Exception e) {
            System.out.println(" ¡¡ ERROR de la Base de Datos durante las pruebas !!");
            e.printStackTrace();
        } finally{
            System.out.println("\n <<< FINALIZANDO PRUEBAS >>>");
            System.out.println("<<< CONTEXTO DE SPRING CERRADO >>>");
        }
    }
}