package ar.org.centro8.poo.curso.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {
    private int idCliente;
    private String nombreCliente;
    private String apellidoCliente;
    private String dni;
    private String telefono;
    private String email;

}


