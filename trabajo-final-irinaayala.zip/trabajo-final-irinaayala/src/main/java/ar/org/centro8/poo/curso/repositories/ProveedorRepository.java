package ar.org.centro8.poo.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.poo.curso.entities.Proveedor;
import ar.org.centro8.poo.curso.repositories.interfaces.I_ProveedorRespository;

@Repository
public class ProveedorRepository implements I_ProveedorRespository{
    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
        "INSERT INTO proveedores (nombre, telefono, email, direccion, observaciones, toma_pedidos, entrega_pedidos) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM proveedores WHERE id_proveedor =?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM proveedores";
    private static final String SQL_UPDATE =
        "UPDATE proveedores SET nombre =?, telefono =?, email =?, direccion =?, observaciones =?, toma_pedidos =?, entrega_pedidos =? WHERE id_proveedor =?";
    private static final String SQL_DELETE =
        "DELETE FROM proveedores WHERE id_proveedor =?";
    private static final String SQL_FIND_BY_EMAIL = 
        "SELECT * FROM proveedores WHERE email =?";

    public ProveedorRepository(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Proveedor proveedor) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, proveedor.getNombre());
            ps.setString(2, proveedor.getTelefono());
            ps.setString(3, proveedor.getEmail());
            ps.setString(4, proveedor.getDireccion());
            ps.setString(5, proveedor.getObservaciones());
            ps.setString(6, proveedor.getTomaPedidos());
            ps.setString(7, proveedor.getEntregaPedidos());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    proveedor.setIdProveedor(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Proveedor findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Proveedor> findAll() throws SQLException {
        List<Proveedor> proveedores = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                proveedores.add(mapRow(rs));
            }
        }
        return proveedores;
    }

    @Override
    public int update(Proveedor proveedor) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, proveedor.getNombre());
            ps.setString(2, proveedor.getTelefono());
            ps.setString(3, proveedor.getEmail());
            ps.setString(4, proveedor.getDireccion());
            ps.setString(5, proveedor.getObservaciones());
            ps.setString(6, proveedor.getTomaPedidos());
            ps.setString(7, proveedor.getEntregaPedidos());
            ps.setInt(8, proveedor.getIdProveedor());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Proveedor> findByEmail(String email) throws SQLException {
        List<Proveedor> proveedores = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EMAIL)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    proveedores.add(mapRow(rs));
                }
            }
        }
        return proveedores;
    }


    private Proveedor mapRow(ResultSet rs) throws SQLException {
        Proveedor p = new Proveedor();
        p.setIdProveedor(rs.getInt("id_proveedor"));
        p.setNombre(rs.getString("nombre"));
        p.setTelefono(rs.getString("telefono"));
        p.setEmail(rs.getString("email"));
        p.setDireccion(rs.getString("direccion"));
        p.setObservaciones(rs.getString("observaciones"));
        p.setTomaPedidos(rs.getString("toma_pedidos"));
        p.setEntregaPedidos(rs.getString("entrega_pedidos"));
        return p;
    }
}


