 INSERT INTO clientes (nombre_cliente, apellido_cliente, dni, telefono, email) VALUES
('Ketherine', 'Garcia', '62154367', '1165783421', 'kathe.garcia@gmail.com'),
('Elena', 'Fernandez', '28999888', '1195423681', 'elena.fernandez@yahoo.com'),
('Damon', 'Hernandez', '30123456', '1165783421', 'da.hernandez@hotmail.com'),
('Anna', 'Navarro', '62957316', '1186234715', 'anna.na@gmail.com'),
('Tyler', 'Mendoza', '20395641', '1165783421', 'tyler.mendoza@yahoo.com'),
('Stefan', 'Romero', '62541389', '1186241336', 'stefan.romero@hotmail.com'),
('Hayley', 'Pérez', '36541289', '1134567890', 'hayley.perez@gmail.com');

INSERT INTO proveedores (nombre, telefono, email, direccion, observaciones, toma_pedidos, entrega_pedidos) VALUES
('Federico', '1196844235', 'federicogn@gmail.com', 'Bellivan 2611', 'Entrega eficaz', 'Lunes y Jueves', 'Martes y Viernes'),
('Omar', '1139876543', 'omarnartura@yahoo.com', 'Rawson 362', 'Descuentos', 'Miércoles', 'Viernes'),
('Sandra', '1196633412', 'sandragranix@hotmail.com', 'Solar 4621', 'Alta calidad productos apto diabeticos', 'Lunes', 'Jueves'),
('Monica', '1174231965', 'monicanaturales@gmail.com', 'Laprida 2050', 'Ofrece descuentos', 'Miércoles', 'Jueves'),
('Mia', '1195332668', 'miadietetica@yahoo.com', 'Pasteur 508', 'Entrega sabados', 'Martes', 'Sabados'),
('Luis', '1139876543', 'luisbrisa@hotmail.com', 'Uruguay 924', 'Excelente servicio y comunicacion clara', 'Lunes', 'Viernes'),
('Alejandro', '1144567890', 'alejandrogranola@gmail.com', 'Murguiondo 3406', 'Puntualidad', 'Martes', 'Jueves');

INSERT INTO productos (nombre_producto, precio, stock, id_proveedor, apto_diabetico, apto_vegano, apto_celiaco) VALUES
('Milanesas de seitan', 8000, 100, 5, FALSE, TRUE, FALSE), -- vegano
('Yogurt de almendras', 1200, 50, 2, TRUE, TRUE, TRUE), -- vegano
('Galletitas de chía', 6000, 150, 4, TRUE, TRUE, FALSE), -- vegano
('Fideos de arroz', 950, 60, 2, FALSE, TRUE, TRUE), -- celiaco
('Tostaditas de arroz', 500, 150, 3, FALSE, TRUE, TRUE), -- celiaco
('Stevia en polvo', 800, 100, 1, TRUE, TRUE, TRUE), -- celiaco
('Brownie de algarroba', 1200, 50, 2, TRUE, TRUE, TRUE), -- diabetico 
('Yogurt descremado sabor natural', 600, 75, 1, TRUE, FALSE, FALSE), -- diabetico
('Leche de almendras sin azucar', 950, 60, 2, TRUE, TRUE, TRUE), -- diabetico
('Milanesas de soja', 500, 150, 3, TRUE, TRUE, FALSE), -- diabetico
('Mantequilla de maní', 1000, 40, 3, FALSE, TRUE, FALSE); -- vegano

INSERT INTO ventas (fecha, total, id_cliente) VALUES
('2024-06-01', 2300.00, 1),
('2024-06-02', 1490.00, 2),
('2024-06-03', 2330.00, 3),
('2024-06-04', 1520.00, 5),
('2024-06-05', 4810.00, 1),
('2024-06-06', 1500.00, 6),
('2024-06-07', 1950.00, 7),
('2024-06-08', 8500.00, 1),
('2024-06-09', 9000.00, 2),
('2024-06-10', 2590.00, 3),
('2024-06-11', 6600.00, 4),
('2024-06-12', 7000.00, 1),
('2024-06-13', 1603.00, 4),
('2024-06-14', 9555.00, 7);

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES
(5,1,2),  
(2,2,1); 

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES
(1,7,2),
(3,3,1);

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES
(4,4,1), 
(5,6,3); 

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES
(5,8, 2),  
(2,3,1); 

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES
(1,3,12),
(2,1,40);

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad) VALUES
(4,2,13), 
(3,11,3); 