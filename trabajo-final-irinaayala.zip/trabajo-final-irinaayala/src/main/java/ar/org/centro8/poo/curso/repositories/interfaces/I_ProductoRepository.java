package ar.org.centro8.poo.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.poo.curso.entities.Producto;

public interface I_ProductoRepository {
    void create(Producto producto) throws SQLException;
    Producto findById(int id) throws SQLException;
    List<Producto> findAll() throws SQLException;
    int update(Producto producto) throws SQLException;
    int delete(int id) throws SQLException;
    List<Producto> findByProveedor(int idProveedor) throws SQLException;

}
